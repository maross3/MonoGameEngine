﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using TestMonogame.Math;

namespace TestMonogame.Components.@abstract
{
    internal abstract class GameObject
    {
        public MonoTransform Transform { get; } = new ();
        public abstract string Name { get; init; }
        public abstract Texture2D Texture { get; init; }


        public int Height => (int)(Texture.Height * Transform.Scale.Y);

        public int Width =>
            (int)(Texture.Width * Transform.Scale.X);

        public Rectangle Bounds =>
            new((int)Transform.Position.X, (int)Transform.Position.Y, Width, Height);

        public abstract void Update(GameTime gameTime);
        public abstract void Draw(SpriteBatch batch);
    }
}
