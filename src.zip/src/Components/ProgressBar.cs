﻿using System.Threading.Tasks.Dataflow;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using TestMonogame.Components.@abstract;
using TestMonogame.Math;
using NotImplementedException = System.NotImplementedException;

namespace TestMonogame.Components
{
    internal class ProgressBar : GameObject
    {
        public override string Name { get; init; }
        public override Texture2D Texture { get; init; }
        public float value { get; set; } = 1f;
        private Vector2 ScaleVector => new Vector2(value + 0.05f, 1);

        public ProgressBar(Vector2 position, Vector2 scale, MonoTransform parent)
        {
            Transform.Position = position;
            Transform.Scale = scale;
            Transform.Parent = parent;
        }

        public override void Update(GameTime gameTime)
        {

        }

        private Vector2 XOffset = new() { X = 3, Y = 1 };

    public override void Draw(SpriteBatch batch)
        {
            batch.Draw(
                Game1.progressBarOneFront,
                Transform.Position + XOffset,
                null,
                Color.White,
                0f,
                new Vector2(0, 0),
                Transform.Scale * ScaleVector,
                SpriteEffects.None,
                0f
            );

            batch.Draw(
                Game1.progressBarOneBack,
                Transform.Position,
                null,
                Color.White,
                0f,
                new Vector2(0, 0),
                Transform.Scale,
                SpriteEffects.None,
                0f
            );
        }
    }
}
