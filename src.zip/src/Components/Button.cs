﻿using System;
using System.Diagnostics;
using System.Threading.Tasks.Dataflow;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using TestMonogame.Components.@abstract;
using TestMonogame.Math;
using Vector2 = Microsoft.Xna.Framework.Vector2;

namespace TestMonogame.Components
{
    internal class Button : GameObject
    {
        public override string Name { get; init; }
        public override Texture2D Texture { get; init; }
        public string Text { get; set; } = "";
        public Vector2 textOffset;
        public Vector2 TextOffset
        {
            get => textOffset;
            set => textOffset = new Vector2(value.X + 22, value.Y + 10);
        }

        private Color _curColor;
        private Color _highlightColor = Color.White;
        private Color _defaultColor = Color.LightGray;
        private Color _disabledColor = Color.Gray;

        public Button(Vector2 position)
        {
            Transform.Position = position;
        }
        public Button(Vector2 position, Vector2 scale)
        {
            Transform.Position = position;
            Transform.Scale = scale;
        }
        public Button(Vector2 position, Vector2 scale, string text)
        {
            Transform.Position = position;
            TextOffset = Transform.Position;

            Transform.Scale = scale;
            Text = text;
        }
        public Button(Vector2 position, Vector2 scale, string text, MonoTransform parent)
        {
            _curColor = _defaultColor;
            Transform.Position = position;
            TextOffset = Transform.Position;

            Transform.Scale = scale;
            Text = text;
            Transform.Parent = parent;
        }
        public bool MouseHover() =>
            Mouse.GetState().X < Transform.Position.X + Width &&
            Mouse.GetState().X > Transform.Position.X  &&
            Mouse.GetState().Y < Transform.Position.Y + Height &&
            Mouse.GetState().Y > Transform.Position.Y;

        private bool _pressed;
        private TimeSpan _msDelayOnPress;
        private static readonly TimeSpan ButtonDelayMs = TimeSpan.FromMilliseconds(260);
            
        public event EventHandler<EventArgs> OnButtonPress;
        public override void Update(GameTime gameTime)
        {
            TextOffset = Transform.Position;
            var mouseHovering = MouseHover();
            _curColor = mouseHovering ? _highlightColor : _defaultColor;

            if (_pressed) _pressed = _msDelayOnPress + ButtonDelayMs > gameTime.TotalGameTime;
            if (_pressed || !mouseHovering || Mouse.GetState().LeftButton != ButtonState.Pressed || _pressed) return;
            _pressed = true;

            _msDelayOnPress = gameTime.TotalGameTime;
            OnButtonPress?.Invoke(this, EventArgs.Empty);
            Debug.WriteLine("Im pressed!");
            _curColor = _defaultColor;
        }

        //light gray = default
        // white = highlight
        // red = disabled
        public override void Draw(SpriteBatch batch)
        {
            batch.Draw(
                Texture,
                Transform.Position,
                null,
                _curColor,
                0f,
                new Vector2(0, 0),
                Transform.Scale,
                SpriteEffects.None,
                0f
            );
            if (Text == "") return;
            batch.DrawString(Game1.electroFontOne,
                Text,
                TextOffset,
            Color.LightGray,
             0,
             Vector2.Zero,
              new Vector2(0.8f),
            SpriteEffects.None,
            0);

        }
    }
}
