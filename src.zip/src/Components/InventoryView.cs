﻿using System;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using TestMonogame.Components.@abstract;
using TestMonogame.Entities;
using TestMonogame.Interface;
using Vector2 = Microsoft.Xna.Framework.Vector2;

// todo fix transform
// import the class and rewrite it
// allow position.Y += 4
// make parents update children ffs.

// click procs like 30 events, needs an 'on get button up'
// Buttons need a get/init text to draw to the button, and a spritfont
// 
namespace TestMonogame.Components
{
    internal class InventoryView : GameObject, IView, IIdleImplemented
    {
        public override string Name { get; init; }
       public override Texture2D Texture { get; init; }

        const float _speed = 30;
        private readonly SpriteFont _font;
        
        public Button saveButton;
        public Button chopWoodButton;
        public ProgressBar progressBarOne;

        public InventoryView(Texture2D tex, SpriteFont font) : base()
        {
            _font = font;
            Texture = tex;
            Transform.Position = new Vector2(17, 49);
            // Transform.Position = new Vector2(0, 0);

            Transform.Scale = new Vector2(0.5f);
        }

        public void Initialize()
        {
            var saveGamePosition = new Vector2(Width * 0.53f, Height * 0.75f);

            saveButton = new Button(saveGamePosition, new Vector2(0.2f, 0.1f), "save\ngame", Transform)
                { Texture = Texture, Name = "saveGameButton" };

            var chopWoodPosition =
                new Vector2(Width * 0.07f, Height * 0.75f);

            chopWoodButton = new Button(chopWoodPosition, new Vector2(0.2f, 0.1f), "chop\nwood", Transform)
                { Texture = Texture, Name = "chopWoodButton"};

            var progressBarOnePosition = new Vector2(Width * 0.09f, Height * 0.6f);
            progressBarOne = new ProgressBar(progressBarOnePosition, new Vector2(0.7f), Transform);

                

        }

        // todo, this is a lerp bar on x axis
        /*
        if (handle.X + 2 < clickX)
        {
            handle.X++;
            value += 0.01f;
            //limit value max
            if (value > 1.0f) { value = 1.0f; }
            //check for right boundary, limit
            if (handle.X > bkgLineWindow.rec_bkg.openedRec.X + Width - 2)
            {
                handle.X = bkgLineWindow.rec_bkg.openedRec.X + Width - 2;
                value = 1.0f; //max
            }
            UpdateHandleValue();
        }
    else if (handle.X + 2 > clickX)
    {
        handle.X--;
        value -= 0.01f;
        //limit value min
        if (value < 0.01f) { value = 0.01f; }
        //check for left boundary, limit
        if (handle.X < bkgLineWindow.rec_bkg.openedRec.X)
        {
            handle.X = bkgLineWindow.rec_bkg.openedRec.X;
            value = 0.01f; //min
        }
        UpdateHandleValue();
    }
        */
#region Vector Helpers to Extract
private readonly Vector2 Down = new()
        { X = 0, Y = _speed };

        private void MoveDown(float number) =>
            Transform.MovePosition(Down * number);

        private readonly Vector2 Up= new()
        { X = 0, Y = -_speed };
        private void MoveUp(float number) =>
            Transform.MovePosition(Up * number);

        private readonly Vector2 Left = new()
        { X = -_speed, Y = 0};
        private void MoveLeft(float number) =>
            Transform.MovePosition(Left * number);
        
        private readonly Vector2 Right = new()
        { X = _speed, Y = 0};
        
        private void MoveRight(float number) =>
            Transform.MovePosition(Right *  number);
        #endregion

        public override void Update(GameTime gameTime)
        {
            saveButton.Update(gameTime);
            chopWoodButton.Update(gameTime);

            var time = (float) gameTime.ElapsedGameTime.TotalSeconds;
            var kstate = Keyboard.GetState();

            if (kstate.IsKeyDown(Keys.Up)) MoveUp(time);
            if (kstate.IsKeyDown(Keys.Down)) MoveDown(time);
            if (kstate.IsKeyDown(Keys.Left)) MoveLeft(time);
            if (kstate.IsKeyDown(Keys.Right)) MoveRight(time);
        }

        public void Accept(object obj)
        {
        }

        public override void Draw(SpriteBatch batch)
        {
            batch.Draw(
                Texture,
                Transform.Position,
                null,
                Color.White,
                0f,
                new Vector2(0, 0),
                Transform.Scale,
                SpriteEffects.None,
                0f
            );

            saveButton.Draw(batch);
            chopWoodButton.Draw(batch);
            progressBarOne.Draw(batch);

        }

        public int LastKnowntime { get; set; }
        public void AdvanceTime(float value)
        {
            progressBarOne.value = value;
        }

        public void ApplySecondDifference(int secondDifference)
        {

        }
    }
}