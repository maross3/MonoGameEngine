﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.Serialization;
using System.Threading.Tasks.Dataflow;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using TestMonogame.Components;
using TestMonogame.Components.@abstract;
using TestMonogame.Entities.@abstract;
using TestMonogame.System;
using NotImplementedException = System.NotImplementedException;

namespace TestMonogame.Entities
{
    // this is our idle entity. Every gameobject that needs to be processed by idle
    // will be included here. You can make game objects, and just add them to this list
    // it call the update and draw fn on each GO with updated idle info.
    // we can use an interface to sperate the GO and feed good logic
    internal interface IIdleImplemented
    {
        public int LastKnowntime { get; set; }
        public void AdvanceTime(float value);
        public void ApplySecondDifference(int secondDifference);
    }

    //todo dependency on idle implemented
    internal class IdleEntity : BaseEntity, IIdleImplemented
    {
        public List<GameObject> components = new();
        public override int ID { get; set; }

        private bool harvesting;
        private TimeSpan lastMS;
        private float targetWaitMS;

        public TimeSpan currentSecondsDelay = TimeSpan.FromSeconds(2);
        // create a pipeline for UI
        // we need an event handler to process ui calls,
        // then provide a single place to invoke that other components will sub to.

        // need an animation pipeline
        // 


        public override void Initialize()
        {
            harvesting = false;
            var inventoryView = new InventoryView(Game1.windowTexture, Game1.electroFontOne);
            inventoryView.Initialize();
            inventoryView.chopWoodButton.OnButtonPress += ChopWoodButton_OnButtonPress;
            components.Add(inventoryView);
        }

        private bool init;

        private void ChopWoodButton_OnButtonPress(object sender, EventArgs e)
        {
            harvesting = !harvesting;
            if (harvesting) targetWaitMS = -1;
            
        }

        public override void Update(GameTime gameTime)
        {
            foreach (var component in components) component.Update(gameTime);
            HandleHarvest(gameTime);
        }

        private int MsTotal => (lastMS + currentSecondsDelay).Milliseconds;

        private void HandleHarvest(GameTime gameTime)
        {
            var gameMs = (float)gameTime.TotalGameTime.TotalMilliseconds;
            var sliderVal = (targetWaitMS - gameMs) / (float)currentSecondsDelay.TotalMilliseconds;

            foreach (var component in components)
                if (component is IIdleImplemented idler)
                    idler.AdvanceTime((targetWaitMS - gameMs) / (float) currentSecondsDelay.TotalMilliseconds);


            if (!harvesting || targetWaitMS > gameMs) return;
            Debug.WriteLine("Hit Log");

            var lastMS = gameTime.TotalGameTime;
            targetWaitMS = (float) lastMS.TotalMilliseconds + (float)currentSecondsDelay.TotalMilliseconds;
        }

        public override void Draw(SpriteBatch batch)
        {
            foreach (var component in components) component.Draw(batch);

            batch.Draw(
                Game1.treeOne,
                new Vector2((int)(Game1.GameWindowBounds.Width * 0.55), 60),
                null,
                Color.White,
                0f,
                new Vector2(0, 0),
                new Vector2(0.4f),
                SpriteEffects.None,
                0f
            );
        }

        public int LastKnowntime { get; set; }
        protected int secondDifference;

        public void AdvanceTime(float value)
        {
        }

        public void ApplySecondDifference(int seconds)
        {
            secondDifference = seconds;
        }
    }
}