﻿using System.Collections.Generic;
using Vector2 = Microsoft.Xna.Framework.Vector2;

namespace TestMonogame.Math
{
    internal class MonoTransform
    {
        private Vector2 _worldSpace;
        private Vector2 _localSpace;
        public Vector2 Scale;

        private MonoTransform _parent;
        public MonoTransform Parent
        {
            get => _parent;
            internal set
            {
                value.AddChild(this);
                _parent = value;
                Position += value.Position;
            }
        }

        public List<MonoTransform> children = new List<MonoTransform>();

        public void AddChild(MonoTransform child)
        {
            children.Add(child);
        }

        public Vector2 Position
        {
            get => _worldSpace;
            set
            {
                foreach (var child in children) child.Position += value - _worldSpace;
                _worldSpace = value;
                LocalPosition = value;
            }
        }

        public Vector2 LocalPosition
        {
            get => _localSpace;
            set
            {
                if (Parent != null) _localSpace = Parent.Position + value;
                else _localSpace = value;

            }
        }
        public void MovePosition(float x, float y) =>
            Position += new Vector2(x, y);
        public void MovePosition(Vector2 variable) =>
            Position += variable;
    }
}