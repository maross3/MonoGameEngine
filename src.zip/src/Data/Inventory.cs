﻿using System.Collections.Generic;

namespace TestMonogame.Data
{
    public class Inventory
    {
        public int ownerId { get; set; }
        public int spaceAllotment { get; set; }
        public Dictionary<string, string> itemAndQuantityDictionary { get; set; }
    }
}
