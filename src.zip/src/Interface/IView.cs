﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace TestMonogame.Interface
{
    internal interface IView
    {
        void Accept(object obj);
    }
}
